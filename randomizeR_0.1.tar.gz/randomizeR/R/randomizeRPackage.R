#' Randomization Procedures - Assessment and Evaluation
#' 
#' \tabular{ll}{
#' Package: \tab randomizeR \cr
#' Type: \tab Package\cr
#' Version: \tab 1.0\cr
#' Date: \tab 2014-12-18\cr
#' License: \tab GPL (>= 2)\cr
#' LazyLoad: \tab yes \cr
#' }
#' 
#' This package provides functionality for randomization in clinical trials.
#' Clinical trials often are accrual. Hence, the patients get allocated into the treatment arms
#' at the time they are admitted in the study. This is reflected in the randomization protocol.
#' If the person electing the patients in the study can guess what treatment will be assigned next
#' he might be able to bias the study. Making use of soft inclusion/exclusion criteria, he may decline
#' a "weak" patient when he can guess that his favoured treatment is going to be next in the
#' allocation list, alleging that the weak patient will have a smaller probability of success for 
#' the treatment (binary case) or smaller average treatment effect (continuous case). The bias
#' introduced this way is called selection bias.
#' This package contains functions for the computation of randomization sequences with various protocols,
#' for the computation of selection bias and patient response for binary as well as continuous endpoints.
#' 
#' 
#' @docType package
#' @name randomizeR-package
#' @aliases randomizeR
#' @title Randomization Procedures - Assessment and Evaluation  
#' @author David Schindler \email{dschindler@@ukaachen.de}, Diane Uschner \email{duschner@@ukaachen.de}
#' @import methods
#' @import ggplot2
#' @importFrom stats dpois pt qpois qt rbinom rnorm t.test
#' @importFrom utils capture.output packageVersion sessionInfo write.table
NULL
