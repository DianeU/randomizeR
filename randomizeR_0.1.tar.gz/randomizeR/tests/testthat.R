require(testthat)

# checking all tests written in the files starting with test_* in the testthat folder
test_check("randomizeR")
